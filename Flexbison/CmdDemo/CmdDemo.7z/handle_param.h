#ifndef HANDLE_PARAM_H
#define HANDLE_PARAM_H

#ifdef __cplusplus
extern "C" {
#endif

void handle_param_d(const char* arg);
void handle_param_f(const char* arg);

#ifdef __cplusplus
}
#endif

#endif // HANDLE_PARAM_H
